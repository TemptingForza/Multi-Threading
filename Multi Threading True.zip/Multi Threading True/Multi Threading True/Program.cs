﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Multi_Threading_True
{
    class Program
    {
        //public static ints for randomizer integer and highest number
        public static int[] randomizer = new int[10000000];
        public static int highnumber = 0;
        public static int highnumber1 = 0;
        public static int highnumber2 = 0;
        public static void method1()
            //for loops and if statement for highnumbers
        {
            int[] randomizer1 = randomizer.Take(randomizer.Length / 2).ToArray();
            for (int i = 0; i < randomizer1.Length; i++)
            {
                if (highnumber1 < randomizer1[i])
                {
                    highnumber1 = randomizer1[i];
                }
            }
        }
        public static void method2()
        {
            int[] randomizer2 = randomizer.Skip(randomizer.Length / 2).ToArray();
            for (int i = 0; i < randomizer2.Length; i++)
            {
                if (highnumber2 < randomizer2[i])
                {
                    highnumber2 = randomizer2[i];
                }
            }
        }

        public static void method3()
        {
            Random r = new Random();
            for (int i = 0; i < randomizer.Length; i++)
            {
                int name = r.Next(1, 10000000);
                randomizer[i] = name;
            }
            return;
        }

        public static void method4()
        {
            int[] randomizer3 = randomizer.Take(randomizer.Length).ToArray();
            for (int i = 0; i < randomizer3.Length; i++)
            {
                if (highnumber < randomizer3[i])
                {
                    highnumber = randomizer3[i];
                }
            }
        }

        public static int method5()
        {
            int highest = 0;
            if (randomizer.Length > 0)
            {
                highest = randomizer[0];
                for (int i = 1; i < randomizer.Length; i++)
                {
                    if (highest < randomizer[i])
                    {
                        highest = randomizer[i];
                    }
                }
            }
            return highest;
        }

        static void Main(string[] args)
            //displays execution time and highest integer
        {
            method3();
            int highestnum = method5();
            Thread thr = new Thread(method4);
            //watch stopwatch
            var watch = new System.Diagnostics.Stopwatch();
            watch.Start();
            thr.Start();//single thread start
            while (thr.IsAlive)
            {
                Thread.Sleep(5); //checking is working or not
            }
            //time end
            watch.Stop();
            Console.WriteLine($"Execution Time for single thread: {watch.ElapsedMilliseconds} ms");
            Console.WriteLine("Highest number is: " + highestnum);
            watch.Restart();
            Thread thr1 = new Thread(method1);
            Thread thr2 = new Thread(method2);
            thr1.Start();
            thr2.Start();
            if (thr1.IsAlive || thr2.IsAlive)
            {
                Thread.Sleep(5);
            }
            watch.Stop(); // 65
            Console.WriteLine($"Execution Time for multi thread: {watch.ElapsedMilliseconds} ms");
            Console.WriteLine("Highest number is: " + highestnum);
            Console.ReadLine();
        }
    }
}
